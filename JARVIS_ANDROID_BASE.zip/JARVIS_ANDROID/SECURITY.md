# Seguridad

- Nunca incrustar OPENAI_API_KEY en la APK.
- Usar secretos efímeros para sesiones de voz.
- OAuth para Spotify y Google.
- Tokens guardados en Android Keystore/Encrypted Storage.
- Control del PC mediante comandos permitidos, no shell arbitrario.
- Confirmación antes de borrar archivos, apagar equipos, enviar mensajes o ejecutar acciones sensibles.
- Home Assistant con token limitado y HTTPS cuando sea posible.
