# JARVIS Android

Proyecto Android nativo con interfaz HUD inspirada en asistentes futuristas.

## Qué incluye esta base
- Interfaz tipo HUD.
- Botón de voz y reconocimiento de voz del sistema.
- Permisos de micrófono/cámara.
- Módulos visuales para visión, Spotify, casa, calendario, recordatorios y PC.
- Estructura preparada para conectar un backend seguro.

## IMPORTANTE: IA y seguridad
No pongas una clave secreta de OpenAI dentro de la APK. Para voz en tiempo real, el móvil debe obtener una credencial efímera desde TU servidor. La documentación oficial recomienda WebRTC para clientes móviles/navegadores y mantener la clave estándar en el servidor.

Arquitectura recomendada:

Android JARVIS
  -> servidor propio
      -> OpenAI Realtime
      -> Spotify OAuth
      -> Google Calendar OAuth
      -> Home Assistant
      -> puente de PC

## Palabra "JARVIS"
La activación permanente tipo "Hey Google" no debe implementarse simplemente dejando un SpeechRecognizer abierto todo el tiempo. Android limita y cambia el comportamiento de reconocimiento/servicios en segundo plano. Para producción conviene usar un detector de palabra de activación dedicado + Foreground Service y cumplir las reglas actuales de Android.

## Control del PC
El móvil no puede controlar de forma segura un PC arbitrario sin un agente/servidor en ese PC. La arquitectura recomendada es:
Android -> HTTPS/WebSocket -> Jarvis PC Agent -> acciones permitidas.

## Siguiente integración
1. Backend de sesiones Realtime.
2. Wake word real.
3. Cámara con análisis de imágenes.
4. Spotify OAuth + playback.
5. Google Calendar OAuth.
6. Home Assistant.
7. PC Agent con lista blanca.
8. Notificaciones/recordatorios.
9. APK firmada.

Consulta las instrucciones del README antes de conectar credenciales.
