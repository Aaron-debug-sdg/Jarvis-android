package com.jarvis.android

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@Composable
fun JarvisApp() {
    val bg = Color(0xFF02060A)
    val cyan = Color(0xFF19D9FF)
    var status by remember { mutableStateOf("SISTEMA EN ESPERA") }
    var transcript by remember { mutableStateOf("Di «JARVIS» para empezar") }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) status = "MICRÓFONO ACTIVADO"
        else status = "PERMISO DE MICRÓFONO DENEGADO"
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            transcript = text
            status = "ORDEN RECIBIDA"
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("J.A.R.V.I.S.", color = cyan, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("PERSONAL AI SYSTEM", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(22.dp))

                Box(
                    modifier = Modifier.size(250.dp)
                        .border(2.dp, cyan, CircleShape)
                        .clickable {
                            if (androidx.core.content.ContextCompat.checkSelfPermission(
                                    androidx.compose.ui.platform.LocalContext.current,
                                    Manifest.permission.RECORD_AUDIO
                                ) != PackageManager.PERMISSION_GRANTED) {
                                micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Te escucho...")
                                }
                                speechLauncher.launch(i)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◉", color = cyan, fontSize = 72.sp)
                        Text("JARVIS", color = cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("PULSA PARA HABLAR", color = Color.Gray, fontSize = 11.sp)
                    }
                }

                Spacer(Modifier.height(22.dp))
                Text(status, color = cyan, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    transcript,
                    color = Color.White,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth()
                        .background(Color(0xFF071018))
                        .padding(16.dp)
                )

                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HudButton("📷 VISIÓN") { status = "CÁMARA: módulo preparado" }
                    HudButton("🎵 SPOTIFY") { status = "SPOTIFY: módulo preparado" }
                    HudButton("🏠 CASA") { status = "DOMÓTICA: módulo preparado" }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HudButton("📅 CALENDARIO") { status = "CALENDARIO: módulo preparado" }
                    HudButton("⏰ RECORDATORIOS") { status = "RECORDATORIOS: módulo preparado" }
                    HudButton("💻 PC") { status = "CONTROL PC: requiere servidor companion" }
                }
            }
        }
    }
}

@Composable
fun HudButton(label: String, action: () -> Unit) {
    Button(
        onClick = action,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF071018),
            contentColor = Color(0xFF19D9FF)
        )
    ) { Text(label, fontSize = 9.sp) }
}
